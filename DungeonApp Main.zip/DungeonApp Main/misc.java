public class misc {
    
}


    // Room monsterRoom1 =     new Room("Monster",true,new int[6],1,1,monster1);
    // Room monsterRoom2 =     new Room("Monster",true,new int[6],2,1,monster2);
    // Room monsterRoom3 =     new Room("Monster",true,new int[6],2,3,monster3);
    // Room monsterRoom4 =     new Room("Monster",true,new int[6],3,1,monster4);
    // Room itemRoom1 =        new Room("Item",false,new int[6],1,0);
    // Room itemRoom2 =        new Room("Item",false,new int[6],1,2);
    // Room itemRoom3 =        new Room("Item",false,new int[6],3,0);
    // Room itemRoom4 =        new Room("Item",false,new int[6],3,2);

    // startRoom.adjacentRooms(startRoom,monsterRoom4,blank,blank,blank);
    // fountainRoom.adjacentRooms(fountainRoom,monsterRoom1,monsterRoom2,monsterRoom3,monsterRoom4);
    // itemRoom1.adjacentRooms(itemRoom1,blank,blank,monsterRoom1,monsterRoom2);
    // itemRoom2.adjacentRooms(itemRoom2,blank,monsterRoom1,blank,monsterRoom3);
    // itemRoom3.adjacentRooms(itemRoom3,monsterRoom2,blank,monsterRoom4,blank);
    // itemRoom4.adjacentRooms(itemRoom4,monsterRoom3,monsterRoom4,blank,blank);
    // monsterRoom1.adjacentRooms(monsterRoom1,bossRoom,itemRoom1,itemRoom2,fountainRoom);
    // monsterRoom2.adjacentRooms(monsterRoom2,itemRoom1,weaponRoom1,fountainRoom,itemRoom3);
    // monsterRoom3.adjacentRooms(monsterRoom3,itemRoom2,fountainRoom,weaponRoom2,itemRoom4);
    // monsterRoom4.adjacentRooms(monsterRoom4,fountainRoom,itemRoom3,itemRoom4,startRoom);
    // bossRoom.adjacentRooms(bossRoom,blank,blank,blank,monsterRoom1);
    // weaponRoom1.adjacentRooms(weaponRoom1,blank, blank, monsterRoom2, blank);
    // weaponRoom2.adjacentRooms(weaponRoom2,blank, monsterRoom3, blank, blank);

    // Item.spawnItems(itemRoom1);
    // Item.spawnItems(itemRoom2);
    // Item.spawnItems(itemRoom3);
    // Item.spawnItems(itemRoom4);

